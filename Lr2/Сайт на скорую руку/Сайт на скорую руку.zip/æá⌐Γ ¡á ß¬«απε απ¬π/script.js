function togglePopup(popupId) {
    let popup = document.getElementById(popupId);
    popup.classList.toggle('active');
event.preventDefault()
}

function closePopup(popupId) {
    let popup = document.getElementById(popupId);
    popup.classList.remove('active');
}

document.addEventListener('click', (e) => {
    
    let popups = document.querySelectorAll('.popup');
    popups.forEach((popup) => {
        if (e.target === popup) {
            popup.classList.remove('active');
        }
    });
});


function sendEmail() {


var name = document.getElementsByName("name")[0].value;
var tel = document.getElementsByName("tel")[0].value;
var Flowers = document.getElementsByName("Flowers")[0].value;
var reason = document.getElementsByName("reason")[0].value;
var who = document.getElementsByName("who")[0].value;
var prise = document.getElementsByName("prise")[0].value;
var color = document.getElementsByName("color")[0].value;
var size = document.getElementsByName("size")[0].value;



var subject = "Новое сообщение от " + name;


var body = "Имя: " + name + "";


body += "Телефон: " + tel + "";


body += "Сообщение:" + Flowers + reason + who + prise + color + size;


window.open("mailto:ekaterinauvarovv@yandex.ru?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body));


}

$(".heart").click(function() { 
    $(this).toggleClass("heart_active"); 
  });
